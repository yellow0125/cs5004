package cs5004.animator.model.animation;

/**
 * This is an enum class represents the various kinds of  animations to shape object.
 */
public enum AnimationType {
  CHANG_COLOR,
  MOVE,
  SCALE,
  REMOVE;
}
